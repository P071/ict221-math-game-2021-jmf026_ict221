# ICT221_MathGame

Starting code for MathGame project.